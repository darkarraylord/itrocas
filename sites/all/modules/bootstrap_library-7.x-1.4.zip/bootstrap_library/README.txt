Bootstrap Library for Drupal

This module loads Bootstrap files, regardless of the theme you are using. It does nothing else.

When using Bootstrap themes is particulary helpfull to correct Browser Support issues, installing response.js

This module does not depend on a specific version of Bootstrap, it just load the version you install, with the components you install on it, either complete or customize.

Installation

- Download Boostrap files on /sites/all/libraries/bootstrap.
- Install and enable Boostrap Library Module.
- Configure on which pages you want to load the libraries (by default everything but admin/*).